<?php

namespace App\Modules\Api\StaffTransformers;


class Visits extends Transformer
{
    public function transform($item, $opt)
    {
         return $item;
    }

}