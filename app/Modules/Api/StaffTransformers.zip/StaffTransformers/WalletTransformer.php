<?php

namespace App\Modules\Api\StaffTransformers;


class WalletTransformer extends Transformer
{
    public function transform($item, $opt)
    {
        return [
            'balance' => $item['balance'],
        ];
    }
//
//    public function merchantWithWallet($items)
//    {
//
//        return array_map([$this, 'merchantWithWalletCallBack'], $items);
//    }

    function merchantWithWallet($item)
    {
//dd($item);


        $data =  [
            'id' => $item['id'],
            'name' => $item['name'],

            'balance' => $item['payment_wallet']['balance'],
            'wallet_id' => $item['payment_wallet']['wallet_id'],
            'mobile' => $item['staff_mobile']
        ];
 
        return $data;
    }
}