<?php
return [
    '100'       => __('ok'),
    '101'       => __('Not Found'),
    '102'       => __('Unauthenticated'),
    '103'       => __('Validation Error'),
    '104'       => __('Content created'),
    '105'       => __('No permissions'),
    '106'       => __('Duplicated'),
    '107'       => __('Action didn\'t work'),
    '108'       => __('Account not verified'),
];